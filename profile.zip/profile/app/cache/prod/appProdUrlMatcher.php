<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        // createProfile
        if ($pathinfo === '/create-profile') {
            return array (  '_controller' => 'AppBundle\\Controller\\ProfileController::renderFormAction',  '_route' => 'createProfile',);
        }

        // viewProfile
        if ($pathinfo === '/view-profile') {
            return array (  '_controller' => 'AppBundle\\Controller\\ProfileController::viewProfileListAction',  '_route' => 'viewProfile',);
        }

        // profileDetails
        if (0 === strpos($pathinfo, '/profile') && preg_match('#^/profile(?:/(?P<id>[^/]++))?$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'profileDetails')), array (  'id' => 0,  '_controller' => 'AppBundle\\Controller\\ProfileController::profileDetailsAction',));
        }

        // saveProfile
        if ($pathinfo === '/save-profile') {
            return array (  '_controller' => 'AppBundle\\Controller\\ProfileController::saveProfileAction',  '_route' => 'saveProfile',);
        }

        // listProfile
        if ($pathinfo === '/list-profile') {
            return array (  '_controller' => 'AppBundle\\Controller\\ProfileController::listProfileAction',  '_route' => 'listProfile',);
        }

        // editProfile
        if ($pathinfo === '/edit-profile') {
            return array (  '_controller' => 'AppBundle\\Controller\\ProfileController::editProfileAction',  '_route' => 'editProfile',);
        }

        // getProfile
        if ($pathinfo === '/get-profile') {
            return array (  '_controller' => 'AppBundle\\Controller\\ProfileController::getProfileAction',  '_route' => 'getProfile',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
