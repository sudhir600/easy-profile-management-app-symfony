/*
Author - Sudhir K gupta
date 09 Sep 2016
code beautifier by http://jsbeautifier.org/
*/

/* re arrange */
$(document).ready(function(e) {
    $("#createProfile,#editProfile").on('submit', (function(e) {
        e.preventDefault();
        var validate = validateFormFields();
        if (validate == 0) {
            $('#message').show().html('Please Fill Mandatory Fields').addClass('errorText');
        } else {
            if ($(this).attr('id') == 'createProfile') {
                var ajaxUrl = '/save-profile';
                var successMsg = "<p>This Profile has been added.<br ><a href='javascript:reLoad()''>Click here to create another profile</a></p>";
            } else {
                var ajaxUrl = '/edit-profile?id=' + $('input[name="profileId"]').val() + '&save=true';
                var successMsg = "profile has been updated.<br /><a class='small' href='javascript:reLoad()'>Click here to refresh this page</a>";
            }
            overlay('Processing...');
            $.ajax({
                url: ajaxUrl,
                type: "POST",
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    if (data == '1') {
                        $("#message").addClass('overlay').html(successMsg);
                    } else {
                        $("#message").html('Opps.. Some error occurred while saving this record.');
                        //$("#message").html(data);
                    }
                },
                fail: function(e) {
                    $("#message").html('Ajax request failed');
                }
            });
        }
    }));
});

function overlay(msg) {
    var elmnt = $("#message");
    elmnt.empty();
    elmnt.addClass('overlay').show().html(msg);
    elmnt.css({
        'height': $('#panel').height() - 70,
        'width': $('#panel').width(),
        'padding-top': eval(($('#panel').height() / 2) - 70),
    });
}

// Function to preview image after validation
$(function() {
    $("#file").change(function() {
        $("#message").empty().hide(); // To remove the previous error message
        var file = this.files[0];
        var imagefile = file.type;
        var match = ["image/jpeg", "image/png", "image/jpg"];
        if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
            $('#previewing').attr('src', 'noimage.png');
            $("#message").show().html("<p id='error'>Please Select A valid Image File. (Only jpeg, jpg and png Images type allowed )</p>");
            return false;
        } else {
            var reader = new FileReader();
            reader.onload = imageIsLoaded;
            reader.readAsDataURL(this.files[0]);
        }
    });
});


function imageIsLoaded(e) {
    $("#file").css("color", "green");
    $('#image_preview, #previewing').css("display", "block");
    $('#previewing').attr('src', e.target.result);
    $('#previewing').attr('width', '250px');
    $('#previewing').attr('height', '230px');
};



function ajaxRequest() {
    $.ajax({
        url: "/save-profile",
        type: "POST",
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData: false,
        success: function(data) {
            console.log(data);
        }
    });
}

function createAnotherProfile() {
    $("#message").hide().removeClass('overlay').html('');
    $('button[type="reset"]').click();
}

$('body').on('click', '#createAnotherProfile', function(e) {
    $("#message").hide().removeClass('overlay').html('');
    $('button[type="reset"]').click();
    $('#previewing').attr('src', '').hide();
})

/* validate form */
function validateFormFields() {
    var errorFlag = 1;
    $("#createProfile input[data-required=true], #editProfile input[data-required=true]").each(function(index) {
        var currVal = $.trim($(this).val());
        if (currVal == '') {
            $(this).addClass('errorValidation');
            errorFlag = 0;
        }else{
         $(this).removeClass('errorValidation');
        }
    });
    return errorFlag;
}

function reLoad() {
    location.reload();
}

/* global validation setting */
$(document).ready(function(e) {
    $('form input[data-required="true"], ' +
        'form input[data-required="true"]').keydown(function() {
        currVal = $.trim($(this).val());
        if (currVal == '') {
            $(this).removeClass('errorValidation');
            errorFlag = 1;
        }
    });
    $('form input[data-required="true"]').change(function() {
        validateFormFields();
    });
});

