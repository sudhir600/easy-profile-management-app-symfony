<?php

namespace AppBundle\Controller;

use Doctrine\DBAL\Driver\PDOException;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\ORM\EntityNotFoundException;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;



class GeneralController extends Controller
{

    public  function crudSystem($sql="",$sql_input,$query_type='select',$fetchType='fetchAssoc')
    {
        $em = $this->getDoctrine()->getEntityManager();
        $connection = $em->getConnection();
        if($query_type=='select') {
            $dataSet = $connection->fetchAssoc($sql, $sql_input);
        }
        elseif($query_type == 'update'){
            $dataSet=$connection->executeQuery($sql,$sql_input);
        }
        elseif($query_type == 'delete'){
            try{
                $connection->executeQuery($sql,$sql_input);
                $dataSet = true;
            }
            catch(PDOException $x){
                $dataSet ='Error Occurred while deleting this record'.$x->getMessage();
            }
        }
        return $dataSet;
    }

}
