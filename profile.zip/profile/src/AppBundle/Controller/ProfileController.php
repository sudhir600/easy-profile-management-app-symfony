<?php

namespace AppBundle\Controller;

use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Response;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;

class ProfileController extends Controller
{
    public $table = 'users';

    public function __construct()
    {
        error_reporting(0); // prevent warning if you are using /web/ url;
    }

    /**
    * @Route("/create-profile", name="createProfile")
    */
    public function renderFormAction()
    {
        return $this->render('profile/createProfileForm.html.twig');
    }

    /**
    * @Route("/view-profile", name="viewProfile")
    */
    public function viewProfileListAction(Request $request)
    {

        $sql = "select count(id) as 'totalRecords' from {$this->table}";
        $response = $this->defaultConnection($sql, '', 'select', false);
        $totalRecords = $response['totalRecords'];

        /* make pagination */
        $item_per_page = 1;
        $pageNumber    = (isset($_REQUEST['page']) == 0 || ''?1:$_REQUEST['page']);
        $total_pages = ceil($totalRecords/$item_per_page);
        $page_position = (($pageNumber-1) * $item_per_page);
        $id = (!isset($_REQUEST['id']) || ($_REQUEST['id']=="")?0:$_REQUEST['id']);
        if ($id==0) {
            $sql = "select * from {$this->table} order by id desc limit 0,1"; // grab latest record
            $id = $totalRecords; // mysql id autoincrement will be equal
        } else {
            $sql = "select * from {$this->table} where id= {$id}";
        }
        $pageNumber = ceil($totalRecords-$id+1);
        if ($pageNumber<=0) {
            $pageNumber=1;  //prevent for unAvailable ids
        }
        $dataSet = $this->defaultConnection($sql, '', 'select', true);
        if (!empty($dataSet)) {
            $dataSet['data']=$dataSet;
            $pagination = $this->myPagination($item_per_page, $id, $totalRecords, $total_pages, 5);
            $dataSet['pagination']= '<div style="float: right"><span class="loader"></span>'.$pagination.'</div>';
        }
        return $this->render('profile/viewProfile.html.twig', array('dataSet'=>$dataSet));
    }

    /**
    * @Route("/profile/{id}", name="profileDetails")
    */
    public function profileDetailsAction($id = 0)
    {
        return $this->render('profile/profileDetails.html.twig');
    }

    /**
    * @Route("/save-profile", name="saveProfile")
    */
    public function saveProfileAction()
    {
          $status=[];
          $uploadDirectory = "uploads/";
          $uploadStatus =$this->uploadImage($_FILES['file'], $uploadDirectory);
        if ($uploadStatus['error']==0) {
            $uploadedFilePath = $uploadDirectory.$uploadStatus['filePath'];


           /* ready to insert data into table */
            $dataSet  =   array(
                              'name'=>$_REQUEST['userName'],
                              'email'=>$_REQUEST['userEmail'],
                              'profile_pic'=>$uploadedFilePath,
                              'phone'=>$_REQUEST['userPhone'],
                              );
            try {
                $sql = "insert into {$this->table} (name,email,profile_pic,phone) values (:name,:email,:profile_pic ,:phone)";
                $response = $this->defaultConnection($sql, $dataSet, 'insert');
                $status['error']=1;
            } catch (Exception $e) {
                $status['error']=0;
                $status['msg'] =$e->getMessage();
            }
        } else {
            $status['error']=1;
            $status['msg'] =$uploadStatus['error'];
        }

          return new Response($status['error']);
    }

    /**
    * @Route("/list-profile", name="listProfile")
    */
    public function listProfileAction()
    {
        $sql = "select id,name,email from {$this->table}";
        $dataSet = $this->defaultConnection($sql, '', 'select', true);
        return $this->render('profile/profileListView.html.twig', array('dataSet'=>$dataSet));
    }
    public function uploadImage($fileObject, $targetDirectory = 'uploads')
    {
        $response = array();
        //$location = $this->get('kernel')->getRootDir() . '/../web/uploads/';
        $validExtensions = array("image/jpeg","image/jpg","image/png");
        $fileArray      = explode(".", $fileObject["name"]);
        $fileExtension  = end($fileArray);
        $actualFileName = $fileArray[0];

        if (isset($fileObject["type"]) && (in_array($fileObject['type'], $validExtensions))) {
            if ($_FILES["file"]["error"] > 0) {
                $response['error'] =  "something error fond with this file.<br >Possible reason can be ".$fileObject["error"];
            } else {
                   $newFileName = rand(1, 1000).date('ymdhis').$fileObject['name'];
                   $sourcePath = $fileObject['tmp_name'];
                   $targetPath = $this->get('kernel')->getRootDir() . "/../web/".$targetDirectory.$newFileName;
                try {
                    move_uploaded_file($sourcePath, $targetPath);
                     $response['error']     =   0;
                     $response['filePath']  =  $newFileName;
                } catch (exception $e) {
                      $response['error']    =  'error found while moving file from temp to '.$targetPath;
                }
            }
        } else {
            $response['error']  =    'Invalid file. can\'t upload ';
        }
        return $response;
    }


    /**
    * @Route("/edit-profile", name="editProfile")
    */
    public function editProfileAction()
    {
        $profileId = (!isset($_REQUEST['id']) || ($_REQUEST['id']=="")?die('Invalid profile id detected'):$_REQUEST['id']);
        // block for update the data
        if (isset($_REQUEST['save'])==true) {
            $dataSet = array(
                  'id'   => $profileId,
                  'name' => $_REQUEST['userName'],
                  'email' => $_REQUEST['userEmail'],
                  'profile_pic' => $_REQUEST['oldProfilePic'],
                  'phone' => $_REQUEST['userPhone'],
              );

            //die('i am in if in');
            $status=[];
            $uploadDirectory = "uploads/";
            $uploadStatus =$this->uploadImage($_FILES['file'], $uploadDirectory);
            if ($uploadStatus['error'] == '0') {
                $dataSet['profile_pic'] = $uploadDirectory . $uploadStatus['filePath'];
            }
            $sql = "update {$this->table} set name        =        :name,
                                              email       =        :email,
                                              profile_pic =        :profile_pic,
                                              phone       =        :phone
                                              WHERE id    =        :id
                                              ";
            try {
                $this->defaultConnection($sql, $dataSet, 'update');
                $status = 1;  //true if done
            } catch (Exception $e) {
                $status   = 0;  //false in not done
            }
            return new Response($status);
        } else {
            $sql = "select * from {$this->table} where id = {$profileId}";
            $dataSet = $this->defaultConnection($sql, '', 'select', false);
            return $this->render('profile/editProfileForm.html.twig', array('dataSet'=>$dataSet));
        }
    }

    /**
    * @Route("/get-profile", name="getProfile")
    */
    public function getProfileAction()
    {
        $ids = (!isset($_REQUEST['ids']) || ($_REQUEST['ids']=="" || 0 ) ? die('<h2>Invalid/Missing profile ids detected.</h2><br /><b>use eg-: get-profile?ids=1,2,3,4</b>'):$_REQUEST['ids']);
        $ids = rtrim($ids, ',');

        $sql = "select * from {$this->table} where id IN ({$ids})";
        $response = $this->defaultConnection($sql, '', 'select', true);
        return new Response(json_encode($response));
    }
    public function myPagination($item_per_page, $current_page, $total_records, $total_pages, $adjacent = 5)
    {
        $pagination = '';
        if ($total_pages > 0 && $total_pages != 1 && $current_page <= $total_pages) {
            $pagination .= '<ul class="pagination">';

            $right_links    = $current_page + $adjacent;
            $previous       = $current_page - $adjacent;
            $next           = $current_page + $adjacent;
            $first_link     = true;

            if ($current_page > 1) {
                $previous_link = ($previous==0)? 1: $current_page-1;
                $pagination .= '<li class="first"><a href="/view-profile?id=1" title="First">&laquo;</a></li>'; //create 1st link
                $pagination .= '<li><a href="/view-profile?id='.$previous_link.'" title="Previous">&lt;</a></li>';          //create previous link
                for ($i = ($current_page-2); $i < $current_page; $i++) {
                    if ($i > 0) {
                        $pagination .= '<li><a href="/view-profile?id='.$i.'" title="Profile Id '.$i.'">'.$i.'</a></li>';
                    }
                }
                $first_link = false;
            }
            if ($first_link) {
                $pagination .= '<li class="first active">'.$current_page.'</li>';
            } elseif ($current_page == $total_pages) {
                $pagination .= '<li class="last active">'.$current_page.'</li>';
            } else {
                $pagination .= '<li class="active">'.$current_page.'</li>';
            }

            for ($i = $current_page+1; $i < $right_links; $i++) {
                if ($i<=$total_pages) {
                    $pagination .= '<li><a href="/view-profile?id='.$i.'" title="Profile Id '.$i.'">'.$i.'</a></li>';
                }
            }
            if ($current_page < $total_pages) {
                    $next_link = ($i > $total_pages) ? $total_pages : $i;
                    $pagination .= '<li><a href="/view-profile?id='.$next_link.'" title="Next">&gt;</a></li>'; //next link
                    $pagination .= '<li class="last"><a href="/view-profile?id='.$total_pages.'" title="Last">&raquo;</a></li>'; //last link
            }

            $pagination .= '</ul>';
        }
        return $pagination;
    }
    public function defaultConnection($sql = "", $sql_input, $query_type = 'select', $fetchAll = true)
    {
        $em = $this->getDoctrine()->getEntityManager();
        $connection = $em->getConnection();
        if ($query_type=='select') {
            if ($fetchAll == false) {
                $queryObj     = $connection->query($sql);
                $dataSet      = $queryObj->fetch();
            } else {
                $sql_input = (!is_array($sql_input)?$sql_input=array():$sql_input);
                $dataSet = $connection->fetchAll($sql, $sql_input);
            }

        } elseif ($query_type == 'update') {
            $dataSet=$connection->executeQuery($sql, $sql_input);
        } elseif ($query_type == 'insert') {
            $dataSet=$connection->executeQuery($sql, $sql_input);
        } elseif ($query_type == 'delete') {
            try {
                $connection->executeQuery($sql, $sql_input);
                $dataSet = true;
            } catch (PDOException $x) {
                $dataSet ='Error Occurred while deleting this record'.$x->getMessage();
            }
        }
        return $dataSet;
    }
}
