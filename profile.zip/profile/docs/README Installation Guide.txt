Steps to setup this test

1. Move this package into htdocs (in xampp) or www (in wamp)
2. Open config/parameters.yml and change your database connection settings. (Assuming that you had import profile.sql database)
3. Open root directory and run composer (like this -  http://goo.gl/nrxJs0)
4. Run this command to start server -: php app/console server:run (like this - http://goo.gl/FDgv5H)
5. If server did not start by any reason. Then use below URL to access all page.

  
	Home 		 	- http://127.0.0.1/profile/web/
	Create Profile	 	- http://127.0.0.1/profile/web/create-profile 
				  (change ajax url /save-profile to 127.0.0.1/profile/web/save-profile, otherwise it will not work )
	Profile List view	- http://127.0.0.1/profile/web/list-profile
	Profile Details		- http://127.0.0.1/profile/web/view-profile?id=1
	Api Endpoint		- http://127.0.0.1/profile/web/get-profile?ids=1,2,3

  

