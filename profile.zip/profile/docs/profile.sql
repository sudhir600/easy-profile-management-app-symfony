-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2016 at 08:31 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `profile`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `profile_pic` varchar(500) NOT NULL,
  `phone` varchar(20) NOT NULL COMMENT '(+91) with country code',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Truncate table before insert `users`
--

TRUNCATE TABLE `users`;
--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `profile_pic`, `phone`) VALUES
(1, 'john D S', 'ds1000@yourstory.com', 'uploads/1.jpg', '987688575'),
(2, 'Munawwar rana', 'Munawwarrana@youtube.com', 'uploads/2.jpg', '123456'),
(3, 'dr. kumar vishwas', 'viswas@manoj.com', 'uploads/3.png', '858585858585'),
(4, 'bcb', 'test@test.co,', 'uploads/4.jpg', '1234633'),
(5, 'ratan kumar gaurav', 'ratan@test.com', 'uploads/5.jpg', '8976885726'),
(6, 'renu vist', 'renu#gmail.com', 'uploads/6.jpg', '8975884875'),
(7, 'dubani', 'pokjs@gmail.com', 'uploads/7.jpg', '123'),
(8, 'Sudhir K gupta', 'sudhirgupta.456@gmail.com', 'uploads/8.jpg', '+1 8000000000'),
(9, 'Rajiv Red FM', 'rajeev@redfm.in', 'uploads/9.jpg', 'sdfsd');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
